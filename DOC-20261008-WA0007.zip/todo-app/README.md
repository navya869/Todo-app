# JavaScript Logic & State Management - To-Do List

**Name:** Navya
**Email:** kuninavya09@gmail.com

## Features
- Full CRUD: create, read, update (Edit button) and delete tasks
- Data saved automatically with `window.localStorage` (survives reloads)
- Filtering: All, Active, Completed
- Dynamic DOM elements with delegated event listeners

## Run
Unzip and open `index.html` in any browser.
