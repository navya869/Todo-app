// To-Do List - JavaScript Logic & State Management
// Author: Navya | kuninavya09@gmail.com
(() => {
  const STORAGE_KEY = "navya_todo_tasks_v1";

  // ---- State ----
  const state = { tasks: load(), filter: "all" };

  // ---- DOM ----
  const form = document.getElementById("task-form");
  const input = document.getElementById("task-input");
  const list = document.getElementById("task-list");
  const filters = document.getElementById("filters");
  const count = document.getElementById("count");
  const empty = document.getElementById("empty");
  const clearBtn = document.getElementById("clear-completed");

  // ---- Persistence (window.localStorage) ----
  function load() {
    try {
      const data = JSON.parse(window.localStorage.getItem(STORAGE_KEY));
      return Array.isArray(data) ? data : [];
    } catch (e) { return []; }
  }
  function save() {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state.tasks)); } catch (e) {}
  }

  // ---- CRUD ----
  function addTask(text) {
    state.tasks.push({ id: Date.now() + Math.random().toString(16).slice(2), text, completed: false });
    commit();
  }
  function toggleTask(id) {
    const t = state.tasks.find(t => t.id === id);
    if (t) t.completed = !t.completed;
    commit();
  }
  function updateTask(id, text) {
    const t = state.tasks.find(t => t.id === id);
    if (t && text.trim()) t.text = text.trim();
    commit();
  }
  function deleteTask(id) {
    state.tasks = state.tasks.filter(t => t.id !== id);
    commit();
  }
  function clearCompleted() {
    state.tasks = state.tasks.filter(t => !t.completed);
    commit();
  }
  function commit() { save(); render(); }

  // ---- Render (dynamic DOM) ----
  function visibleTasks() {
    if (state.filter === "active") return state.tasks.filter(t => !t.completed);
    if (state.filter === "completed") return state.tasks.filter(t => t.completed);
    return state.tasks;
  }

  function render() {
    list.innerHTML = "";
    const items = visibleTasks();

    items.forEach(task => {
      const li = document.createElement("li");
      li.className = "item" + (task.completed ? " done" : "");
      li.dataset.id = task.id;

      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = task.completed;
      cb.dataset.action = "toggle";
      cb.setAttribute("aria-label", "Mark complete");

      const span = document.createElement("span");
      span.className = "text";
      span.textContent = task.text;

      const edit = document.createElement("button");
      edit.className = "icon";
      edit.dataset.action = "edit";
      edit.textContent = "Edit";

      const del = document.createElement("button");
      del.className = "icon del";
      del.dataset.action = "delete";
      del.textContent = "Delete";

      li.append(cb, span, edit, del);
      list.appendChild(li);
    });

    const left = state.tasks.filter(t => !t.completed).length;
    count.textContent = `${left} task${left === 1 ? "" : "s"} left`;

    empty.hidden = items.length > 0;
    empty.textContent = state.tasks.length === 0
      ? "No tasks yet. Add your first one above."
      : `No ${state.filter} tasks.`;

    document.querySelectorAll(".filter").forEach(b =>
      b.classList.toggle("active", b.dataset.filter === state.filter));
  }

  function startEdit(li) {
    const id = li.dataset.id;
    const task = state.tasks.find(t => t.id === id);
    const field = document.createElement("input");
    field.className = "edit-input";
    field.value = task.text;
    li.querySelector(".text").replaceWith(field);
    field.focus();
    const finish = () => updateTask(id, field.value);
    field.addEventListener("blur", finish);
    field.addEventListener("keydown", e => {
      if (e.key === "Enter") field.blur();
      if (e.key === "Escape") { field.removeEventListener("blur", finish); render(); }
    });
  }

  // ---- Event listeners (delegated) ----
  form.addEventListener("submit", e => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    addTask(text);
    input.value = "";
    input.focus();
  });

  list.addEventListener("click", e => {
    const btn = e.target.closest("[data-action]");
    if (!btn) return;
    const li = btn.closest(".item");
    const id = li.dataset.id;
    if (btn.dataset.action === "delete") deleteTask(id);
    if (btn.dataset.action === "edit") startEdit(li);
  });
  list.addEventListener("change", e => {
    if (e.target.dataset.action === "toggle") toggleTask(e.target.closest(".item").dataset.id);
  });

  filters.addEventListener("click", e => {
    const b = e.target.closest(".filter");
    if (!b) return;
    state.filter = b.dataset.filter;
    render();
  });

  clearBtn.addEventListener("click", clearCompleted);

  render();
})();
